{
    'name': 'POS Loyalty Disable Company Rule - 14',
    'version': '14.0.0.1',
    'category': 'Point Of Sale',
    'author': 'Mast Information Technology - Bahrain',
    'summary': "Disable lot company rule",
    'depends': ['pos_loyalty'],
    #'website': 'http://www.mast-it.com',
    'data': [

             ],
    'installable': True,
    'qweb': ['static/src/xml/*.xml'],
}
